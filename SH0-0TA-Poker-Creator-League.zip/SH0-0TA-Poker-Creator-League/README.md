# SH0 0TA Poker — Sponsored Creator League Edition

A Texas-aware, free-to-play social poker platform with sponsor-funded prize events, creator leagues, leaderboards, cosmetics, VIP membership, and an admin sponsorship workflow.

> This edition intentionally blocks paid-entry poker, player-funded prize pools, direct wagering, and chip cash-out. Purchases are cosmetic/VIP only and cannot improve odds, tournament eligibility, leaderboard placement, or prize outcomes.

## Included systems

- Multiplayer Texas Hold'em free-play table
- Sponsored tournaments with **free entry only**
- Creator leagues and seasons
- Leaderboards
- Cosmetic shop
- VIP membership flag
- Admin sponsor dashboard data APIs
- Prize eligibility rules
- No-purchase entry controls
- Real-money gambling lockout protections
- Provably fair deck commitment/reveal
- Hand evaluator and tests
- React UI with tabs for table, tournaments, league, shop, and admin

## Quick start

```bash
cp .env.example .env
npm install
npm run dev
```

Client: http://localhost:5173
API: http://localhost:3000

## Important operating rule

Allowed:

```txt
Free tournament entry → sponsor-funded prize → eligibility review → prize payout
Cosmetic purchase → visual item only → no gameplay/prize advantage
VIP subscription → cosmetic/status perks only → no prize advantage
```

Blocked:

```txt
Player pays entry/rebuy → money goes to prize pool → winner receives pool
Player buys chips → chips are cashed out
Purchase increases odds, ranking, eligibility, or prize value
```

## Suggested next production upgrades

1. Replace in-memory stores with PostgreSQL tables in `server/src/db/schema.sql`.
2. Add real authentication and socket auth middleware.
3. Add official rules acceptance and version tracking.
4. Add sponsor contracts and prize fulfillment workflows.
5. Add tax reporting workflow for prizes.
6. Add fraud controls, duplicate-account detection, and geolocation eligibility checks.
7. Add admin audit logs.
