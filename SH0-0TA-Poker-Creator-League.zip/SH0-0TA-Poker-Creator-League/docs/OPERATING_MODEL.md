# Operating Model

## Product positioning

SH0 0TA Poker is a free-to-play social poker and creator competition platform.

## Monetization

- Sponsored tournaments
- Sponsored creator rooms
- Ads and brand integrations
- Cosmetic shop
- VIP subscription for cosmetic/status perks only
- Season pass for cosmetic rewards only
- Merch and event partnerships

## Prize funding

Prizes must be funded by sponsors, the platform marketing budget, or approved promotional budget — not by player entry fees, rebuys, chip purchases, or pooled player payments.

## Required consumer disclosures

- No purchase necessary for prize events
- Purchases do not increase chances of winning
- Free chips have no cash value
- Cosmetics do not affect gameplay
- Entry is subject to eligibility, official rules, fraud review, and jurisdiction restrictions
