# Compliance Guardrails

This repo is engineered to prevent gambling-like flows by default.

## Locked flags

```env
REAL_MONEY_ENABLED=false
PLAYER_FUNDED_PRIZES_ENABLED=false
PAID_TOURNAMENT_ENTRY_ENABLED=false
CHIP_CASHOUT_ENABLED=false
```

## Guardrails implemented

- Tournament entry price must be zero.
- Prize source must be `SPONSOR`, `PLATFORM_PROMO`, or `MERCH_PARTNER`.
- Player purchases cannot be linked to prize funding.
- Rebuys with money are blocked.
- Free chips cannot be withdrawn or redeemed for cash.
- VIP/cosmetic purchases cannot boost ranking or entry odds.

## Production checklist

- Official rules per tournament
- Eligibility screen
- Rules acceptance versioning
- Sponsor agreement records
- Prize fulfillment records
- Tax reporting workflow
- Fraud review queue
- Admin audit logs
- Age/geolocation gating if required by counsel
